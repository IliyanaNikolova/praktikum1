CREATE DATABASE Zodia

use Zodia

CREATE TABLE Signs
(id_sign int PRIMARY KEY,
name_sign nvarchar(15),
period_sign nvarchar(20))

CREATE TABLE People
(id_person int PRIMARY KEY,
name_person nvarchar(15),
date_person date,
sign_id int FOREIGN KEY REFERENCES Signs(id_sign))

INSERT Signs
VALUES ()