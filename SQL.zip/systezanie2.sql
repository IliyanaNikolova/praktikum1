use Systezanie

SELECT name_player,fam_player,name_team
FROM Players
JOIN Teams
ON Teams.id_team=Players.team_id
