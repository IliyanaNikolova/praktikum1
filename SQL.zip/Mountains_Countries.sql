﻿CREATE DATABASE Mountains_Contries

use Mountains_Contries

CREATE TABLE Continents
(continent_cod char(2) PRIMARY KEY,
continent_name nvarchar(50) UNIQUE)

CREATE TABLE Countries
(country_kod char(2) PRIMARY KEY,
country_name nvarchar(50) UNIQUE,
capital nvarchar(20),
kod_continent char(2) FOREIGN KEY REFERENCES Continents(continent_cod))

CREATE TABLE Mountains
(id int PRIMARY KEY,
mountain_name nvarchar(60))

CREATE TABLE Mountains_Countries
(mountain_id int FOREIGN KEY REFERENCES Mountains(id),
country_cod char(2) FOREIGN KEY REFERENCES Countries(country_kod))

CREATE TABLE Peak
(id int PRIMARY KEY,
peak_name nvarchar(50),
elevation int,
mountain_id int FOREIGN KEY REFERENCES Mountains(id))

INSERT Continents
VALUES ('AF', 'Africa'),
('AN', 'Antarctica'),
('AS', 'Asia'),
('EU', 'Europe'),
('NA', 'North America'),
('OC', 'Oceania'),
('SA', 'South America')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES ('AD', 'Andorra', 'EU','Andorra la Vella');

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('AE', 'United Arab Emirates', 'AS', 'Abu Dhabi'),
('AF', 'Afghanistan', 'AS', 'Kabul'),
('AG', 'Antigua and Barbuda', 'NA', 'St. Jones'),
('AI', 'Anguilla', 'NA', 'The Valley'),
('AL', 'Albania', 'EU', 'Tirana'),
('AM', 'Armenia', 'AS', 'Yerevan'),
('AO', 'Angola', 'AF', 'Luanda'),
('AQ', 'Antarctica', 'AN', '');

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('AR', 'Argentina', 'SA', 'Buenos Aires'),
('AS', 'American Samoa', 'OC', 'Pago Pago'),
('AT', 'Austria', 'EU', 'Vienna'),
('AU', 'Australia', 'OC', 'Canberra'),
('AW', 'Aruba', 'NA', 'Oranjestad'),
('AZ', 'Azerbaijan', 'AS', 'Baku')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('BA', 'Bosnia and Herzegovina', 'EU', 'Sarajevo'),
('BB', 'Barbados', 'NA', 'Bridgetown'),
('BD', 'Bangladesh', 'AS', 'Dhaka'),
('BE', 'Belgium', 'EU', 'Brussels'),
('BF', 'Burkina Faso', 'AF','Ouagadougou'),
('BG', 'Bulgaria','EU', 'Sofia')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('BH', 'Bahrain', 'AS', 'Manama'),
('BI', 'Burundi', 'AF', 'Bujumbura'),
('BJ', 'Benin', 'AF', 'Porto-Novo'),
('BL', 'Saint Barthélemy', 'NA', 'Gustavia'),
('BM', 'Bermuda', 'NA', 'Hamilton'),
('BN', 'Brunei', 'AS','Bandar Seri Begawan')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('BO', 'Bolivia', 'SA', 'Sucre'),
('BQ', 'Bonaire', 'NA', ''),
('BR', 'Brazil', 'SA', 'Brasília'),
('BS', 'Bahamas', 'NA','Nassau'),
('BT', 'Bhutan', 'AS', 'Thimphu'),
('BV', 'Bouvet Island', 'AN', ''),
('BW', 'Botswana', 'AF', 'Gaborone')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('BY', 'Belarus', 'EU', 'Minsk'),
('BZ', 'Belize', 'NA', 'Belmopan'),
('CA', 'Canada', 'NA', 'Ottawa'),
('CC', 'Cocos Islands', 'AS', 'West Island'),
('CD', 'Democratic Republic of the Congo', 'AF', 'Kinshasa'),
('CF', 'Central African Republic', 'AF', 'Bangui'),
('CG', 'Republic of the Congo', 'AF', 'Brazzaville')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('CH', 'Switzerland', 'EU', 'Berne'),
('CI', 'Ivory Coast', 'AF', 'Yamoussoukro'),
('CK', 'Cook Islands', 'OC', 'Avarua'),
('CL', 'Chile', 'SA', 'Santiago'),
('CM', 'Cameroon', 'AF', 'Yaoundé')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('CN', 'China', 'AS', 'Beijing'),
('CO', 'Colombia', 'SA', 'Bogotá'),
('CR', 'Costa Rica', 'NA', 'San José'),
('CU', 'Cuba', 'NA', 'Havana'),
('CV', 'Cape Verde', 'AF', 'Praia')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('CW', 'Curacao', 'NA', 'Willemstad'),
('CX', 'Christmas Island', 'AS', 'The Settlement'),
('CY', 'Cyprus', 'EU', 'Nicosia'),
('CZ', 'Czech Republic', 'EU', 'Prague'),
('DE', 'Germany', 'EU', 'Berlin'),
('DJ', 'Djibouti', 'AF', 'Djibouti')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('DK', 'Denmark', 'EU', 'Copenhagen'),
('DM', 'Dominica', 'NA', 'Roseau'),
('DO', 'Dominican Republic', 'NA', 'Santo Domingo'),
('DZ', 'Algeria', 'AF', 'Algiers'),
('EC', 'Ecuador', 'SA', 'Quito'),
('EE', 'Estonia', 'EU', 'Tallinn')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('EG', 'Egypt', 'AF', 'Cairo'),
('EH', 'Western Sahara', 'AF', 'El Aaiún'),
('ER', 'Eritrea', 'AF', 'Asmara'),
('ES', 'Spain', 'EU', 'Madrid'),
('ET', 'Ethiopia', 'AF', 'Addis Ababa'),
('FI', 'Finland', 'EU', 'Helsinki')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('FJ', 'Fiji', 'OC', 'Suva'),
('FK', 'Falkland Islands', 'SA', 'Stanley'),
('FM', 'Micronesia', 'OC', 'Palikir'),
('FO', 'Faroe Islands', 'EU', 'Tórshavn'),
('FR', 'France', 'EU', 'Paris'),
('GA', 'Gabon', 'AF', 'Libreville'),
('GB', 'United Kingdom', 'EU', 'London')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('GD', 'Grenada', 'NA', 'St. George'),
('GE', 'Georgia', 'AS', 'Tbilisi'),
('GF', 'French Guiana', 'SA', 'Cayenne'),
('GG', 'Guernsey', 'EU', 'St Peter Port'),
('GH', 'Ghana', 'AF', 'Accra'),
('GI', 'Gibraltar', 'EU', 'Gibraltar')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('GL', 'Greenland', 'NA', 'Nuuk'),
('GM', 'Gambia', 'AF', 'Banjul'),
('GN', 'Guinea', 'AF', 'Conakry'),
('GP', 'Guadeloupe', 'NA', 'Basse-Terre'),
('GQ', 'Equatorial Guinea', 'AF', 'Malabo')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('GR', 'Greece', 'EU', 'Athens'),
('GS', 'South Georgia and the South Sandwich Islands', 'AN', 'Grytviken'),
('GT', 'Guatemala', 'NA', 'Guatemala City'),
('GU', 'Guam', 'OC', 'Hagåtña'),
('GW', 'Guinea-Bissau', 'AF', 'Bissau'),
('GY', 'Guyana', 'SA', 'Georgetown'),
('HK', 'Hong Kong', 'AS', 'Hong Kong')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('HM', 'Heard Island and McDonald Islands', 'AN', ''),
('HN', 'Honduras', 'NA', 'Tegucigalpa'),
('HR', 'Croatia', 'EU', 'Zagreb'),
('HT', 'Haiti', 'NA', 'Port-au-Prince'),
('HU', 'Hungary', 'EU', 'Budapest'),
('ID', 'Indonesia', 'AS', 'Jakarta'),
('IE', 'Ireland', 'EU', 'Dublin')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('IL', 'Israel', 'AS', 'Jerusalem'),
('IM', 'Isle of Man', 'EU', 'Douglas'),
('IN', 'India', 'AS', 'New Delhi'),
('IO', 'British Indian Ocean Territory', 'AS', ''),
('IQ', 'Iraq', 'AS', 'Baghdad'),
('IR', 'Iran', 'AS', 'Tehran')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('IS', 'Iceland', 'EU', 'Reykjavik'),
('IT', 'Italy', 'EU', 'Rome'),
('JE', 'Jersey', 'EU', 'Saint Helier'),
('JM', 'Jamaica', 'NA', 'Kingston'),
('JO', 'Jordan', 'AS', 'Amman'),
('JP', 'Japan', 'AS', 'Tokyo'),
('KE', 'Kenya', 'AF', 'Nairobi'),
('KG', 'Kyrgyzstan', 'AS', 'Bishkek'),
('KH', 'Cambodia', 'AS', 'Phnom Penh'),
('KI', 'Kiribati', 'OC', 'Tarawa')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('KM', 'Comoros', 'AF', 'Moroni')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('KN', 'Saint Kitts and Nevis', 'A', 'Basseterre')   --ne se vkluchva

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('KP', 'North Korea', 'AS', 'Pyongyang')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('KR', 'South Korea', 'AS', 'Seoul'),
('KW', 'Kuwait', 'AS', 'Kuwait City')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('KY', 'Cayman Islands', 'NA', 'George Town'),
('KZ', 'Kazakhstan', 'AS', 'Astana'),
('LA', 'Laos', 'AS', 'Vientiane'),
('LB', 'Lebanon', 'AS', 'Beirut')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('LC', 'Saint Lucia','NA', 'Castries'),
('LI', 'Liechtenstein', 'EU', 'Vaduz'),
('LK', 'Sri Lanka', 'AS', 'Colombo'),
('LR', 'Liberia', 'AF', 'Monrovia'),
('LS', 'Lesotho', 'AF', 'Maseru'),
('LT', 'Lithuania', 'EU', 'Vilnius')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('LU', 'Luxembourg', 'EU', 'Luxembourg'),
('LV', 'Latvia', 'EU', 'Riga'),
('LY', 'Libya', 'AF', 'Tripoli'),
('MA', 'Morocco', 'AF', 'Rabat'),
('MC', 'Monaco', 'EU', 'Monaco')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('MD', 'Moldova', 'EU', 'Chisinau'),
('ME', 'Montenegro', 'EU', 'Podgorica'),
('MF', 'Saint Martin', 'NA', 'Marigot'),
('MG', 'Madagascar', 'AF', 'Antananarivo'),
('MH', 'Marshall Islands', 'OC', 'Majuro'),
('MK', 'Macedonia', 'EU', 'Skopje')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('ML', 'Mali', 'AF', 'Bamako'),
('MM', 'Myanmar', 'AS', 'Nay Pyi Taw'),
('MN', 'Mongolia', 'AS', 'Ulan Bator'),
('MO', 'Macao', 'AS', 'Macao'),
('MP', 'Northern Mariana Islands', 'OC', 'Saipan'),
('MQ', 'Martinique', 'NA', 'Fort-de-France'),
('MR', 'Mauritania', 'AF', 'Nouakchott'),
('MS', 'Montserrat', 'NA', 'Plymouth')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('MT', 'Malta', 'EU', 'Valletta'),
('MU', 'Mauritius', 'AF', 'Port Louis'),
('MV', 'Maldives', 'AS', 'Malé'),
('MW', 'Malawi', 'AF', 'Lilongwe'),
('MX', 'Mexico', 'NA', 'Mexico City'),
('MY', 'Malaysia', 'AS', 'Kuala Lumpur'),
('MZ', 'Mozambique', 'AF', 'Maputo'),
('NA', 'Namibia', 'AF', 'Windhoek')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('NC', 'New Caledonia', 'OC', 'Noumea'),
('NE', 'Niger', 'AF', 'Niamey'),
('NF', 'Norfolk Island', 'OC', 'Kingston'),
('NG', 'Nigeria', 'AF', 'Abuja'),
('NI', 'Nicaragua', 'NA', 'Managua'),
('NL', 'Netherlands', 'EU', 'Amsterdam'),
('NO', 'Norway', 'EU', 'Oslo'),
('NP', 'Nepal', 'AS', 'Kathmandu')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('NR', 'Nauru', 'OC', ''),
('NU', 'Niue', 'OC', 'Alofi'),
('NZ', 'New Zealand', 'OC', 'Wellington'),
('OM', 'Oman', 'AS', 'Muscat'),
('PA', 'Panama', 'NA', 'Panama City'),
('PE', 'Peru', 'SA', 'Lima'),
('PF', 'French Polynesia', 'OC', 'Papeete'),
('PG', 'Papua New Guinea', 'OC', 'Port Moresby'),
('PH', 'Philippines', 'AS', 'Manila'),
('PK', 'Pakistan', 'AS', 'Islamabad')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('PL', 'Poland', 'EU', 'Warsaw'),
('PM', 'Saint Pierre and Miquelon', 'NA', 'Saint-Pierre'),
('PN', 'Pitcairn Islands', 'OC', 'Adamstown'),
('PR', 'Puerto Rico', 'NA', 'San Juan'),
('PS', 'Palestine', 'AS', ''),
('PT', 'Portugal', 'EU', 'Lisbon'),
('PW', 'Palau', 'OC', 'Melekeok-Palau State')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('PY', 'Paraguay', 'SA', 'Asunción'),
('QA', 'Qatar', 'AS', 'Doha'),
('RE', 'Réunion', 'AF', 'Saint-Denis'),
('RO', 'Romania', 'EU', 'Bucharest'),
('RS', 'Serbia', 'EU', 'Belgrade'),
('RU', 'Russia', 'EU', 'Moscow')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('RW', 'Rwanda', 'AF', 'Kigali'),
('SA', 'Saudi Arabia', 'AS', 'Riyadh'),
('SB', 'Solomon Islands', 'OC', 'Honiara'),
('SC', 'Seychelles', 'AF', 'Victoria'),
('SD', 'Sudan', 'AF', 'Khartoum'),
('SE', 'Sweden', 'EU', 'Stockholm'),
('SG', 'Singapore', 'AS', 'Singapore'),
('SH', 'Saint Helena', 'AF', 'Jamestown'),
('SI', 'Slovenia', 'EU', 'Ljubljana'),
('SJ', 'Svalbard and Jan Mayen', 'EU', 'Longyearbyen'),
('SK', 'Slovakia','EU', 'Bratislava')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('SL', 'Sierra Leone', 'AF', 'Freetown'),
('SM', 'San Marino', 'EU', 'San Marino'),
('SN', 'Senegal', 'AF', 'Dakar'),
('SO', 'Somalia', 'AF', 'Mogadishu'),
('SR', 'Suriname', 'SA', 'Paramaribo'),
('SS', 'South Sudan', 'AF', 'Juba'),
('ST', 'São Tomé and Príncipe', 'AF', 'São Tomé'),
('SV', 'El Salvador', 'NA', 'San Salvador'),
('SX', 'Sint Maarten', 'NA', 'Philipsburg'),
('SY', 'Syria', 'AS', 'Damascus')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('SZ', 'Swaziland', 'AF', 'Mbabane'),
('TC', 'Turks and Caicos Islands', 'NA', 'Cockburn Town'),
('TD', 'Chad', 'AF', 'Djamena'),
('TF', 'French Southern Territories', 'AN', 'Port-aux-Français'),
('TG', 'Togo', 'AF', 'Lomé'),
('TH', 'Thailand', 'AS', 'Bangkok'),
('TJ', 'Tajikistan', 'AS', 'Dushanbe'),
('TK', 'Tokelau', 'OC', ''),
('TL', 'East Timor', 'OC', 'Dili'),
('TM', 'Turkmenistan', 'AS', 'Ashgabat')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('TN', 'Tunisia', 'AF', 'Tunis'),
('TO', 'Tonga', 'OC', 'Nuku-alofa'),
('TR', 'Turkey', 'AS', 'Ankara'),
('TT', 'Trinidad and Tobago', 'NA', 'Port of Spain'),
('TV', 'Tuvalu', 'OC', 'Funafuti'),
('TW', 'Taiwan', 'AS', 'Taipei'),
('TZ', 'Tanzania', 'AF', 'Dodoma'),
('UA', 'Ukraine', 'EU', 'Kyiv'),
('UG', 'Uganda', 'AF', 'Kampala'),
('UM', 'U.S. Minor Outlying Islands','OC', ''),
('US', 'United States', 'NA', 'Washington')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('UY', 'Uruguay', 'SA', 'Montevideo'),
('UZ', 'Uzbekistan', 'AS', 'Tashkent'),
('VA', 'Vatican City', 'EU', 'Vatican'),
('VC', 'Saint Vincent and the Grenadines', 'NA', 'Kingstown'),
('VE', 'Venezuela', 'SA', 'Caracas'),
('VG', 'British Virgin Islands', 'NA', 'Road Town'),
('VI', 'U.S. Virgin Islands', 'NA', 'Charlotte Amalie'),
('VN', 'Vietnam', 'AS', 'Hanoi'),
('VU', 'Vanuatu', 'OC', 'Port Vila'),
('WF', 'Wallis and Futuna', 'OC', 'Mata-Utu')

INSERT Countries(country_kod,country_name,kod_continent,capital)
VALUES 
('WS', 'Samoa', 'OC', 'Apia'),
('XK', 'Kosovo', 'EU', 'Pristina'),
('YE', 'Yemen', 'AS', 'Sanaa'),
('YT', 'Mayotte', 'AF', 'Mamoutzou'),
('ZA', 'South Africa', 'AF', 'Pretoria'),
('ZM', 'Zambia', 'AF', 'Lusaka'),
('ZW', 'Zimbabwe', 'AF', 'Harare')


INSERT Mountains (id,mountain_name)
VALUES (1, 'Alaska Range'),
(2, 'Alborz'),
(3, 'Andes'),
(4, 'Balkan Mountains'),
(5, 'Caucasus'),
(6, 'Cordillera Neovolcanica'),
(7, 'Ellsworth Mountains'),
(8, 'Executive Committee Range'),
(9, 'Himalayas'),
(10, 'Jayawijaya Mountains'),
(11, 'Karakoram'),
(12, 'Kenyan Highlands'),
(13, 'Kilimanjaro'),
(14, 'Kilimanjaro Region'),
(15, 'Maoke Mountains'),
(16, 'Pirin'),
(17, 'Rila'),
(18, 'Saint Elias Mountains'),
(19, 'Sentinel Range'),
(20, 'Southern Highlands'),
(21, 'The Sudirman Range'),
(22, 'Trans-Mexican Volcanic Belt'),
(23, 'Rhodope Mountains'),
(24, 'Vitosha'),
(25, 'Strandza'),
(26, 'Monte Rosa')

INSERT INTO Mountains_Countries (mountain_id, country_cod)
VALUES (3, 'AR'),
(4, 'BG'),
(16, 'BG'),
(17, 'BG'),
(23, 'BG'),
(24, 'BG'),
(25, 'BG'),
(18, 'CA'),
(26, 'CH'),
(3, 'CL'),
(9, 'CN'),
(11, 'CN'),
(5, 'GE'),
(10, 'ID'),
(15, 'ID'),
(21, 'ID'),
(9, 'IN'),
(2, 'IR'),
(26, 'IT'),
(12, 'KE'),
(6, 'MX'),
(22, 'MX'),
(9, 'NP'),
(20, 'PG'),
(11, 'PK'),
(5, 'RU'),
(13, 'TZ'),
(14, 'TZ'),
(1, 'US')

INSERT Peak (id, peak_name, elevation, mountain_id)
VALUES (62, 'Aconcagua', 6962, 3),
(63, 'Botev', 2376, 4),
(64, 'Carstensz Pyramid', 4884, 21),
(65, 'Damavand', 5610, 2),
(66, 'Dykh-Tau', 5205, 5),
(67, 'Elbrus', 5642, 5),
(68, 'Everest', 8848, 9),
(69, 'Julianatop', 4760, 10),
(70, 'K2', 8611, 11),
(71, 'Kangchenjunga', 8586, 9),
(72, 'Kilimanjaro', 5895, 13),
(73, 'Malyovitsa', 2729, 17),
(74, 'Mawenzi', 5149, 14),
(75, 'Monte Pissis', 6793, 3),
(76, 'Mount Giluwe', 4368, 20),
(77, 'Mount Kenya', 5199, 12),
(78, 'Mount Logan', 5959, 18),
(79, 'Mount McKinley', 6194, 1),
(80, 'Mount Shinn', 4661, 19),
(81, 'Mount Sidley', 4285, 8),
(82, 'Mount Tyree', 4852, 19),
(83, 'Musala', 2925, 17),
(84, 'Ojos del Salado', 6893, 3),
(85, 'Pico de Orizaba', 5636, 22),
(86, 'Puncak Trikora', 4750, 15),
(87, 'Shkhara', 5193, 5),
(88, 'Vihren', 2914, 16),
(89, 'Vinson Massif', 4897, 7),
(90, 'Golyam Perelik', 2191, 23),
(91, 'Shirokolashki Snezhnik', 2188, 23),
(92, 'Golyam Persenk', 2091, 23),
(93, 'Batashki Snezhnik', 2082, 23),
(94, 'Cerro Bonete', 6759, 3),
(95, 'Galán', 5912, 3),
(96, 'Mercedario', 6720, 3),
(97, 'Pissis', 6795, 3),
(98, 'Lhotse', 8516, 9),
(99, 'Makalu', 8462, 9),
(100, 'Cho Oyu', 8201, 9),
(101, 'Kutelo', 2908, 16),
(102, 'Banski Suhodol', 2884, 16),
(103, 'Golyam Polezhan', 2851, 16),
(104, 'Kamenitsa', 2822, 16),
(105, 'Malak Polezhan', 2822, 16),
(106, 'Malka Musala', 2902, 17),
(107, 'Orlovets', 2685, 17),
(108, 'Vezhen', 2198, 4),
(109, 'Kom', 2016, 4)




