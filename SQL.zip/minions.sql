CREATE DATABASE Minions

use Minions

CREATE TABLE MinionsCitizen
(id int PRIMARY KEY,
name_minions varchar(10),
age int)

CREATE TABLE Towns
(id_town int PRIMARY KEY,
name_town varchar(10))

ALTER TABLE MinionsCitizen
ADD town_id int FOREIGN KEY REFERENCES Towns(id_town)

INSERT Towns
VALUES (1,'New York'),
       (2,'London'),
	   (3,'Hollywood')

INSERT MinionsCitizen
VALUES (1,'Kevin',22,1),
       (2,'Bob',15,3),
	   (3,'Stewart', NULL,2)


TRUNCATE TABLE MinionsCitizen
DELETE FROM Towns

DROP TABLE MinionsCitizen
DROP TABLE Towns

