﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kniga_visualno_progr
{
    public partial class Form1 : Form
    {
        List<Kniga> knigi = new List<Kniga>();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nameKn = textBox1.Text;
            string zanr = textBox2.Text;
            string nameAvtor = textBox3.Text;
            Kniga kniga = new Kniga(nameKn,zanr,nameAvtor);
            knigi.Add(kniga);
            //knigi.Add(kniga);
            //knigi.Add(kniga.nameAvtor);
            listBox1.Items.Add(kniga.NameKn);
            
            if(!comboBox2.Items.Contains(kniga.NameAvtor))
                comboBox2.Items.Add(kniga.NameAvtor);

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string searchBook = listBox1.SelectedItem.ToString();
            Kniga newKniga = knigi.Find(x => x.NameKn == searchBook);
            if(newKniga!=null)
            { label7.Text = $"{newKniga.NameAvtor}-{newKniga.Zanr}"; }
        }

        

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string searchAutor = comboBox2.SelectedItem.ToString();
            foreach(Kniga kniga in knigi)
            {
                if (searchAutor.Equals(kniga.NameAvtor))
                    listBox2.Items.Add(kniga.NameKn);
            }
        }
    }
}
