﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kniga_visualno_progr
{
    internal class Kniga
    {
        private string nameKn;
        private string zanr;
        private string nameAvtor;

        public string NameKn
        {
            get { return nameKn; }
            set { nameKn = value; }
        }

        public string Zanr
        {
            get { return zanr; }
            set { zanr = value; }
        }

        public string NameAvtor
        {
            get { return nameAvtor; }
            set { nameAvtor = value; }
        }
        public Kniga(string nameKn, string zanr, string nameAvtor)
        {
            this.NameKn = nameKn;
            this.Zanr = zanr;
            this.NameAvtor = nameAvtor;
        }


    }
}
